# app.py
from flask import Flask, render_template, request, redirect, url_for, jsonify
import os
import voice_auth

from pydub import AudioSegment
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'wav', 'flac'}

@app.route('/recognize/<string:fname>', methods=['GET'])
def recognize(fname):
    if not fname:
        return jsonify({"Error": "missing user data"})
    fname="./uploads/"+fname
        # fname = "C:\\Users\\varin\Documents\\PyProjects\\Voice-Authentication-CNN\\data\\wav\Han\\testh.flac"
    result = voice_auth.recognize(fname)
    return jsonify({'Hi ': result + ", how I can help you"})


@app.route('/enroll', methods=['POST'])
def enroll():
    data = request.json
    # result = voice_auth.enroll(data['a'], data['b'])
    result="teting"
    return jsonify({'result': result})





def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('index'))

    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('index.html', files=files)


@app.route('/static/action/<filename>')
def action(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    # Perform some action with the file (e.g., play the audio, analyze it, etc.)
    # Here's an example using pydub to analyze the audio file.
    audio = AudioSegment.from_file(file_path)
    print(file_path)
    duration = audio.duration_seconds
    return f'File: {filename}, Duration: {duration} seconds'



if __name__ == '__main__':
    app.run(port=5001, debug=True)
